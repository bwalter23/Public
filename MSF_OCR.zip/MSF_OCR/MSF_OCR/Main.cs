﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MSF_OCR.Forms;
using MSF_OCR.Models;
using System.IO;
using System.Diagnostics;
using Google.Cloud.Vision.V1;
using Sparrow;


namespace MSF_OCR
{
    public partial class Main : Form
    {
        string credentials = "";
        string video = "";
        //GetTemplateForm template = new GetTemplateForm();
        string filePath;
        List<FieldCoordinates> Fields = new List<FieldCoordinates>();
        List<ID> IDs = Load_Id.LoadID_File();


        public Main()
        {
            InitializeComponent();

        }
        private void btnVideo_Click(object sender, EventArgs e)
        {
            // How to use
            // ----------
            // var ffMpeg = new NReco.VideoConverter.FFMpegConverter();
            // ffMpeg.ConvertMedia("input.mov", "output.mp4", Format.mp4);

            openFileDialog1.ShowDialog();
            video = openFileDialog1.FileName;
            if (Path.GetExtension(video).Equals(".mp4"))
            {
                var ffMpeg = new NReco.VideoConverter.FFMpegConverter();
                
            }
            
        }
        private void LaunchCommandLineApp(string input, string outputFile)
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.CreateNoWindow = false;
        }
        private void btnCreateTemplate_Click(object sender, EventArgs e)
        {
            GetTemplateForm template = new GetTemplateForm();
            template.ShowDialog();
            Fields = template.Fields;
            filePath = template.filePath;
        }

        private void btnAPI_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            credentials = openFileDialog1.FileName;
            if (Path.GetExtension(credentials).Equals(".json"))
                System.Environment.SetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS", credentials);
            else MessageBox.Show("No File Found");

        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            //string filePath = _image.ToString();
            string extension = Path.GetExtension(filePath);
            List<Roster> roster = new List<Roster>();
            string prevName ="";

            int x = 1;
            while (File.Exists(filePath))
            {
                #region Google Cloud Vision API
                // Load an image from a local file.
                var image = Google.Cloud.Vision.V1.Image.FromFile(filePath); ;               
                var client = ImageAnnotatorClient.Create();
                ImageContext image_context = new ImageContext();
                image_context.LanguageHints.Add("en");
                var response = client.DetectText(image, image_context);


                //var color_response = client.DetectImageProperties(image)
                #endregion

                List<CharDetails> details = new List<CharDetails>();

                foreach (var field in Fields)
                { 
                    CharDetails detail = new CharDetails();
                    detail.fieldName = field.attribute;
                    detail.fieldValue = GetPropertyValue(response, field.vertices);
                    details.Add(detail);
                }
                List<CharDetails> sortedList = new List<CharDetails>();
                sortedList = details.OrderBy(o => o.fieldName == "Tags")
                    .ThenBy(o => o.fieldName == "Abil4")
                    .ThenBy(o => o.fieldName == "Abil3")
                    .ThenBy(o => o.fieldName == "Abil2")
                    .ThenBy(o => o.fieldName == "Abil1")
                    .ThenBy(o => o.fieldName == "Stars")
                    .ThenBy(o => o.fieldName == "Gear")
                    .ThenBy(o => o.fieldName == "Level")
                    .ThenBy(o => o.fieldName == "Power")
                    .ThenBy(o => o.fieldName == "Name").ToList();
                details.Clear();
                details = sortedList;

                if (details.Where(t => t.fieldName == "Name").Select(s => s.fieldValue).FirstOrDefault() != prevName)
                {
                    if (details.Where(t => t.fieldName == "Tags").Select(s => s.fieldValue.Contains("MINION")).FirstOrDefault())
                    {
                        details.Where(t => t.fieldName == "Abil4").Select(s => { s.fieldValue = details.Where(t2 => t2.fieldName == "Abil3").Select(s2 => s2.fieldValue).FirstOrDefault(); return s; }).ToList();
                        //details.Where(t => t.fieldName == "Abil3").Select(s => s.fieldValue = "0");
                        details.Where(t => t.fieldName == "Abil3").Select(s => { s.fieldValue = "0"; return s; }).ToList();
                    }
                    roster.Add(new Roster
                    {
                        CharacterName = details.Where(t => t.fieldName == "Name").Select(s => s.fieldValue).FirstOrDefault(),
                        Details = details
                    });
                    prevName = details.Where(t => t.fieldName == "Name").Select(s => s.fieldValue).FirstOrDefault();
                    filePath = filePath.Replace(x + extension, ++x + extension);
                }
                else
                    filePath = filePath.Replace(x + extension, ++x + extension);
                #region failure
                //chars.name = GetPropertyValue(response, Fields.Where(t => t.attribute == "Name").Select(s => s.vertices).FirstOrDefault());
                //if (chars.name != prevName)
                //{
                //    chars.power = GetPropertyValue(response, Fields.Where(t => t.attribute == "Power").Select(s => s.vertices).FirstOrDefault());
                //    chars.tags = GetPropertyValue(response, Fields.Where(t => t.attribute == "Tags").Select(s => s.vertices).FirstOrDefault());
                //    chars.ability1Level = GetPropertyValue(response, Fields.Where(t => t.attribute == "Abil1").Select(s => s.vertices).FirstOrDefault());
                //    chars.ability2Level = GetPropertyValue(response, Fields.Where(t => t.attribute == "Abil2").Select(s => s.vertices).FirstOrDefault());
                //    chars.ability3Level = GetPropertyValue(response, Fields.Where(t => t.attribute == "Abil3").Select(s => s.vertices).FirstOrDefault());
                //    chars.ability4Level = GetPropertyValue(response, Fields.Where(t => t.attribute == "Abil4").Select(s => s.vertices).FirstOrDefault());
                //    chars.level = GetPropertyValue(response, Fields.Where(t => t.attribute == "Level").Select(s => s.vertices).FirstOrDefault());
                //    chars.stars = GetPropertyValue(response, Fields.Where(t => t.attribute == "Stars").Select(s => s.vertices).FirstOrDefault());
                //    chars.gear = GetPropertyValue(response, Fields.Where(t => t.attribute == "Gear").Select(s => s.vertices).FirstOrDefault());

                //    roster.Add(chars);
                //}

                //roster.Add(details);
                #endregion

            }

            string csvPath = "C:/Users/BWalter/Desktop/SideStuff/Alliance/ffmpeg/bin/Video/Roster.csv";
            var csv = new StringBuilder();
            csv.AppendLine("id, label, unlocked, power, level, gearLevel, yellowStars, redStars, basic, special, ultimate, passive");
            using (var file = File.CreateText(csvPath))
            {
                foreach (var character in roster)
                {
                    foreach (var detail in character.Details)
                    {
                        switch (detail.fieldName)
                        {
                            case "Name":
                                switch (detail.fieldValue)
                                {
                                    case "YO-YO":
                                        detail.fieldValue = detail.fieldValue.Replace("-", "");
                                        break;
                                    case "RHIND":
                                        detail.fieldValue = detail.fieldValue.Replace("D", "O");
                                        break;
                                }
                                if( detail.fieldValue.Contains("HYORA"))
                                    detail.fieldValue = detail.fieldValue.Replace("HYORA", "HYDRA");
                                //csv.Append("\"" + detail.fieldValue.ToLower().Replace(" ", "-").Replace(".", "").Replace("(", "").Replace(")", "").Replace("'", "") + "\",");
                                csv.Append("\"" + IDs.Where(t => t.name.ToLower() == detail.fieldValue.ToLower()).Select(s => s.id).FirstOrDefault() + "\",");
                                csv.Append("\"" + detail.fieldValue + "\",");
                                csv.Append("TRUE,");
                                break;
                            case "Power":
                                csv.Append("\"" + detail.fieldValue.Replace(",","") + "\",");
                                break;
                            case "Level":
                                if(detail.fieldValue == "")
                                {
                                    csv.Append("\"" + "1" + "\",");
                                }
                                else
                                    csv.Append("\"" + detail.fieldValue + "\",");
                                break;
                            case "Stars":
                                string[] str1;
                                string val;
                                str1 = detail.fieldValue.Split('/');
                                if (str1[0] == "MAX")
                                    val = "7";
                                else
                                {
                                    switch (str1[1].Trim(' '))
                                    {
                                        case "300":
                                            val = "6";
                                            break;
                                        case "200":
                                            val = "5";
                                            break;
                                        case "130":
                                            val = "4";
                                            break;
                                        case "80":
                                            val = "3";
                                            break;
                                        case "55":
                                            val = "2";
                                            break;
                                        default:
                                            val = "1";
                                            break;
                                    }
                                }
                                csv.Append("\"" + val + "\",");
                                csv.Append("0,");
                                break;
                            case "Abil1":
                            case "Abil2":
                            case "Abil3":
                            case "Abil4":
                                string abilVal = "";
                                for (int i=0; i< detail.fieldValue.Length; i++)
                                {
                                    if (Char.IsDigit(detail.fieldValue[i]))
                                        abilVal += detail.fieldValue[i];
                                }
                                if (abilVal == "")
                                    abilVal = "1";
                                csv.Append("\"" + abilVal + "\",");
                                break;
                            case "Tags":
                                break;
                            default:
                                csv.Append("\"" + detail.fieldValue.Replace("Level", "").Replace("Tier", "").Replace("(Max]","") + "\",");
                                break;

                        }

                    }
                    csv.AppendLine();

                }
                file.WriteLine(csv);    
            }  
        }

        

        string GetPropertyValue(IReadOnlyList<EntityAnnotation> response, SearchBox box)
        {
            //bool debug = false;
            //string text = "";
            StringBuilder builder = new StringBuilder();
            foreach (var annotation in response)
            {
                //if (symbol.Text == "6")
                //    debug = true;
                var min_x = Min(annotation.BoundingPoly.Vertices[0].X, annotation.BoundingPoly.Vertices[1].X, annotation.BoundingPoly.Vertices[2].X, annotation.BoundingPoly.Vertices[3].X);
                var max_x = Max(annotation.BoundingPoly.Vertices[0].X, annotation.BoundingPoly.Vertices[1].X, annotation.BoundingPoly.Vertices[2].X, annotation.BoundingPoly.Vertices[3].X);
                var min_y = Min(annotation.BoundingPoly.Vertices[0].Y, annotation.BoundingPoly.Vertices[1].Y, annotation.BoundingPoly.Vertices[2].Y, annotation.BoundingPoly.Vertices[3].Y);
                var max_y = Max(annotation.BoundingPoly.Vertices[0].Y, annotation.BoundingPoly.Vertices[1].Y, annotation.BoundingPoly.Vertices[2].Y, annotation.BoundingPoly.Vertices[3].Y);

                if (min_x >= box.x1 && max_x <= box.x2 && min_y >= box.y1 && max_y <= box.y2)
                {
                    builder.Append(annotation.Description).Append(" ");
                    

                    //if (symbol.Property.DetectedBreak.Type.Equals(1) || symbol.Property.DetectedBreak.Type.Equals(3))
                    //    text += ' ';
                    //if (symbol.Property.DetectedBreak.Type.Equals(2))
                    //    text += '\t';
                    //if (symbol.Property.DetectedBreak.Type.Equals(5))
                    //    text += '\n';
                }

            }
            //text = builder.ToString().TrimEnd(' ');
            return builder.ToString().TrimEnd(' ');
        }
        double Min(double val1, double val2, double val3, double val4)
        {
            return Math.Min(Math.Min(val1, val2), Math.Min(val3, val4));
        }
        double Max(double val1, double val2, double val3, double val4)
        {
            return Math.Max(Math.Max(val1, val2), Math.Max(val3, val4));
        }

        
    }
}
