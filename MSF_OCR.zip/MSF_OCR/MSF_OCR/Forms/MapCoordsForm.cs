﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MSF_OCR.Forms
{
    public partial class MapCoordsForm : Form
    {
        Image _image;

        Point startPos;      // mouse-down position
        Point currentPos;    // current mouse position
        bool drawing;        // busy drawing
        List<Rectangle> rectangles = new List<Rectangle>();  // previous rectangles

        public string x1 = "";
        public string x2 = "";
        public string y1 = "";
        public string y2 = "";


        private Rectangle getRectangle()
        {
            return new Rectangle(
                Math.Min(startPos.X, currentPos.X),
                Math.Min(startPos.Y, currentPos.Y),
                Math.Abs(startPos.X - currentPos.X),
                Math.Abs(startPos.Y - currentPos.Y));
        }
        public MapCoordsForm(Image image)
        {
            InitializeComponent();
            _image = image;
        }

        private void MapCoordsForm_MouseDown(object sender,
    System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                currentPos = startPos = e.Location;
                drawing = true;
                label1.Text = e.X.ToString();
                label2.Text = e.Y.ToString();
            }
        }
        private void MapCoordsForm_MouseMove(object sender,
            System.Windows.Forms.MouseEventArgs e)
        {
            currentPos = e.Location;
            if (drawing) canvas1.Invalidate();
            label3.Text = e.X.ToString();
            label4.Text = e.Y.ToString();
        }
        private void MapCoordsForm_MouseUp(object sender,
               System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                if (drawing)
                {
                    drawing = false;
                    var rc = getRectangle();
                    if (rc.Width > 0 && rc.Height > 0) rectangles.Add(rc);
                    canvas1.Invalidate();
                }

                x1 = label1.Text;
                y1 = label2.Text;
                x2 = label3.Text;
                y2 = label4.Text;
            }
            Close();
        }
        private void MapCoordsForm_Paint(object sender, PaintEventArgs e)
        {
            if (rectangles.Count > 0) e.Graphics.DrawRectangles(Pens.Black, rectangles.ToArray());
            if (drawing) e.Graphics.DrawRectangle(Pens.Red, getRectangle());
        }

        private void MapCoordsForm_Load(object sender, EventArgs e)
        {
            canvas1.Size = this.Size;
            canvas1.BackgroundImage = _image;
        }
    }
}
