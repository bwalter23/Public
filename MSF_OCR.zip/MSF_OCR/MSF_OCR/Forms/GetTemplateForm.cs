﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MSF_OCR.Forms;
using MSF_OCR.Models;

namespace MSF_OCR.Forms
{
    public partial class GetTemplateForm : Form
    {
        public static string FILEPATH = "C:/Users/BWalter/Desktop/SideStuff/Alliance/ffmpeg/bin/Video/Sample/char1.png";
        public string filePath = FILEPATH;
        public List<FieldCoordinates> Fields = new List<FieldCoordinates>();
        //public Template template = new Template();
        public Image image = Image.FromFile(FILEPATH);

        public GetTemplateForm()
        {
            InitializeComponent();

        }

        private void btnPower_Click(object sender, EventArgs e)
        {
            MapCoordsForm map = new MapCoordsForm(image);
            map.Size = new Size(image.Width+50, image.Height + 100);
            map.ShowDialog();

            lblPower.Text = string.Concat(map.x1, ',', map.y1, ',', map.x2, ',', map.y2);

        }

        private void btnTags_Click(object sender, EventArgs e)
        {
            MapCoordsForm map = new MapCoordsForm(image);
            map.Size = new Size(image.Width + 50, image.Height + 100);
            map.ShowDialog();

            lblTags.Text = string.Concat(map.x1, ',', map.y1, ',', map.x2, ',', map.y2);
        }

        private void btnAbil1_Click(object sender, EventArgs e)
        {
            MapCoordsForm map = new MapCoordsForm(image);
            map.Size = new Size(image.Width + 50, image.Height + 100);
            map.ShowDialog();

            lblAbil1.Text = string.Concat(map.x1, ',', map.y1, ',', map.x2, ',', map.y2);
        }

        private void btnAbil2_Click(object sender, EventArgs e)
        {
            MapCoordsForm map = new MapCoordsForm(image);
            map.Size = new Size(image.Width + 50, image.Height + 100);
            map.ShowDialog();

            lblAbil2.Text = string.Concat(map.x1, ',', map.y1, ',', map.x2, ',', map.y2);
        }

        private void btnAbil3_Click(object sender, EventArgs e)
        {
            MapCoordsForm map = new MapCoordsForm(image);
            map.Size = new Size(image.Width + 50, image.Height + 100);
            map.ShowDialog();

            lblAbil3.Text = string.Concat(map.x1, ',', map.y1, ',', map.x2, ',', map.y2);
        }

        private void btnAbil4_Click(object sender, EventArgs e)
        {
            MapCoordsForm map = new MapCoordsForm(image);
            map.Size = new Size(image.Width + 50, image.Height + 100);
            map.ShowDialog();

            lblAbil4.Text = string.Concat(map.x1, ',', map.y1, ',', map.x2, ',', map.y2);
        }

        private void btnLevel_Click(object sender, EventArgs e)
        {
            MapCoordsForm map = new MapCoordsForm(image);
            map.Size = new Size(image.Width + 50, image.Height + 100);
            map.ShowDialog();

            lblLevel.Text = string.Concat(map.x1, ',', map.y1, ',', map.x2, ',', map.y2);
        }

        private void btnStars_Click(object sender, EventArgs e)
        {
            MapCoordsForm map = new MapCoordsForm(image);
            map.Size = new Size(image.Width + 50, image.Height + 100);
            map.ShowDialog();

            lblStars.Text = string.Concat(map.x1, ',', map.y1, ',', map.x2, ',', map.y2);
        }

        private void btnGear_Click(object sender, EventArgs e)
        {
            MapCoordsForm map = new MapCoordsForm(image);
            map.Size = new Size(image.Width + 50, image.Height + 100);
            map.ShowDialog();

            lblGear.Text = string.Concat(map.x1, ',', map.y1, ',', map.x2, ',', map.y2);
        }

        private void btnName_Click(object sender, EventArgs e)
        {
            MapCoordsForm map = new MapCoordsForm(image);
            map.Size = new Size(image.Width + 50, image.Height + 100);
            map.ShowDialog();

            lblName.Text = string.Concat(map.x1, ',', map.y1, ',', map.x2, ',', map.y2);
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {

            #region failure
            //Template template = new Template();

            //template.attribute = "Power";
            //double coord = 0;

            //string[] axis =lblPower.Text.Split(',');
            //double.TryParse(axis[0], out coord);
            //template.vertices.x1 = coord;
            //double.TryParse(axis[1], out coord);
            //template.vertices.y1 = coord;
            //double.TryParse(axis[2], out coord);
            //template.vertices.x2 = coord;
            //double.TryParse(axis[3], out coord);
            //template.vertices.y2 = coord;
            #endregion

            var labels = this.Controls.OfType<Label>()
                          .Where(c => c.Name.StartsWith("lbl"))
                          .ToList();
            foreach (var label in labels)
            {
                FieldCoordinates Field = new FieldCoordinates();

                Field.attribute = label.Name.Replace("lbl","");
                double coord = 0;

                string[] axis = label.Text.Split(',');
                double.TryParse(axis[0], out coord);
                Field.vertices.x1 = coord;
                double.TryParse(axis[1], out coord);
                Field.vertices.y1 = coord;
                double.TryParse(axis[2], out coord);
                Field.vertices.x2 = coord;
                double.TryParse(axis[3], out coord);
                Field.vertices.y2 = coord;
                Fields.Add(Field);
            }
            Close();
        }
    }
}
