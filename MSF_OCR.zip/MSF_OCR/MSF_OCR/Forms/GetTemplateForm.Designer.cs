﻿namespace MSF_OCR.Forms
{
    partial class GetTemplateForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPower = new System.Windows.Forms.Label();
            this.btnPower = new System.Windows.Forms.Button();
            this.btnCreate = new System.Windows.Forms.Button();
            this.lblTags = new System.Windows.Forms.Label();
            this.btnTags = new System.Windows.Forms.Button();
            this.btnAbil1 = new System.Windows.Forms.Button();
            this.btnAbil2 = new System.Windows.Forms.Button();
            this.btnAbil3 = new System.Windows.Forms.Button();
            this.btnAbil4 = new System.Windows.Forms.Button();
            this.btnLevel = new System.Windows.Forms.Button();
            this.btnStars = new System.Windows.Forms.Button();
            this.btnGear = new System.Windows.Forms.Button();
            this.btnName = new System.Windows.Forms.Button();
            this.lblAbil1 = new System.Windows.Forms.Label();
            this.lblAbil2 = new System.Windows.Forms.Label();
            this.lblAbil3 = new System.Windows.Forms.Label();
            this.lblAbil4 = new System.Windows.Forms.Label();
            this.lblLevel = new System.Windows.Forms.Label();
            this.lblStars = new System.Windows.Forms.Label();
            this.lblGear = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblPower
            // 
            this.lblPower.AutoSize = true;
            this.lblPower.Location = new System.Drawing.Point(124, 59);
            this.lblPower.Name = "lblPower";
            this.lblPower.Size = new System.Drawing.Size(100, 13);
            this.lblPower.TabIndex = 0;
            this.lblPower.Text = "1019,109,1252,177";
            // 
            // btnPower
            // 
            this.btnPower.Location = new System.Drawing.Point(27, 53);
            this.btnPower.Name = "btnPower";
            this.btnPower.Size = new System.Drawing.Size(80, 24);
            this.btnPower.TabIndex = 1;
            this.btnPower.Text = "Set Power";
            this.btnPower.UseVisualStyleBackColor = true;
            this.btnPower.Click += new System.EventHandler(this.btnPower_Click);
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(275, 317);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(129, 24);
            this.btnCreate.TabIndex = 2;
            this.btnCreate.Text = "Create Template";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // lblTags
            // 
            this.lblTags.AutoSize = true;
            this.lblTags.Location = new System.Drawing.Point(124, 89);
            this.lblTags.Name = "lblTags";
            this.lblTags.Size = new System.Drawing.Size(100, 13);
            this.lblTags.TabIndex = 3;
            this.lblTags.Text = "1028,182,1328,258";
            // 
            // btnTags
            // 
            this.btnTags.Location = new System.Drawing.Point(27, 83);
            this.btnTags.Name = "btnTags";
            this.btnTags.Size = new System.Drawing.Size(80, 24);
            this.btnTags.TabIndex = 4;
            this.btnTags.Text = "Set Tags";
            this.btnTags.UseVisualStyleBackColor = true;
            this.btnTags.Click += new System.EventHandler(this.btnTags_Click);
            // 
            // btnAbil1
            // 
            this.btnAbil1.Location = new System.Drawing.Point(27, 113);
            this.btnAbil1.Name = "btnAbil1";
            this.btnAbil1.Size = new System.Drawing.Size(80, 24);
            this.btnAbil1.TabIndex = 5;
            this.btnAbil1.Text = "Set Ability 1";
            this.btnAbil1.UseVisualStyleBackColor = true;
            this.btnAbil1.Click += new System.EventHandler(this.btnAbil1_Click);
            // 
            // btnAbil2
            // 
            this.btnAbil2.Location = new System.Drawing.Point(27, 143);
            this.btnAbil2.Name = "btnAbil2";
            this.btnAbil2.Size = new System.Drawing.Size(80, 24);
            this.btnAbil2.TabIndex = 6;
            this.btnAbil2.Text = "Set Ability 2";
            this.btnAbil2.UseVisualStyleBackColor = true;
            this.btnAbil2.Click += new System.EventHandler(this.btnAbil2_Click);
            // 
            // btnAbil3
            // 
            this.btnAbil3.Location = new System.Drawing.Point(27, 173);
            this.btnAbil3.Name = "btnAbil3";
            this.btnAbil3.Size = new System.Drawing.Size(80, 24);
            this.btnAbil3.TabIndex = 7;
            this.btnAbil3.Text = "Set Ability 3";
            this.btnAbil3.UseVisualStyleBackColor = true;
            this.btnAbil3.Click += new System.EventHandler(this.btnAbil3_Click);
            // 
            // btnAbil4
            // 
            this.btnAbil4.Location = new System.Drawing.Point(27, 203);
            this.btnAbil4.Name = "btnAbil4";
            this.btnAbil4.Size = new System.Drawing.Size(80, 24);
            this.btnAbil4.TabIndex = 8;
            this.btnAbil4.Text = "Set Ability 4";
            this.btnAbil4.UseVisualStyleBackColor = true;
            this.btnAbil4.Click += new System.EventHandler(this.btnAbil4_Click);
            // 
            // btnLevel
            // 
            this.btnLevel.Location = new System.Drawing.Point(27, 233);
            this.btnLevel.Name = "btnLevel";
            this.btnLevel.Size = new System.Drawing.Size(80, 24);
            this.btnLevel.TabIndex = 9;
            this.btnLevel.Text = "Set Level";
            this.btnLevel.UseVisualStyleBackColor = true;
            this.btnLevel.Click += new System.EventHandler(this.btnLevel_Click);
            // 
            // btnStars
            // 
            this.btnStars.Location = new System.Drawing.Point(27, 262);
            this.btnStars.Name = "btnStars";
            this.btnStars.Size = new System.Drawing.Size(80, 24);
            this.btnStars.TabIndex = 10;
            this.btnStars.Text = "Set Stars";
            this.btnStars.UseVisualStyleBackColor = true;
            this.btnStars.Click += new System.EventHandler(this.btnStars_Click);
            // 
            // btnGear
            // 
            this.btnGear.Location = new System.Drawing.Point(27, 292);
            this.btnGear.Name = "btnGear";
            this.btnGear.Size = new System.Drawing.Size(80, 24);
            this.btnGear.TabIndex = 11;
            this.btnGear.Text = "Set Gear Tier";
            this.btnGear.UseVisualStyleBackColor = true;
            this.btnGear.Click += new System.EventHandler(this.btnGear_Click);
            // 
            // btnName
            // 
            this.btnName.Location = new System.Drawing.Point(27, 322);
            this.btnName.Name = "btnName";
            this.btnName.Size = new System.Drawing.Size(80, 24);
            this.btnName.TabIndex = 12;
            this.btnName.Text = "Set Name";
            this.btnName.UseVisualStyleBackColor = true;
            this.btnName.Click += new System.EventHandler(this.btnName_Click);
            // 
            // lblAbil1
            // 
            this.lblAbil1.AutoSize = true;
            this.lblAbil1.Location = new System.Drawing.Point(124, 119);
            this.lblAbil1.Name = "lblAbil1";
            this.lblAbil1.Size = new System.Drawing.Size(88, 13);
            this.lblAbil1.TabIndex = 13;
            this.lblAbil1.Text = "246,158,421,190";
            // 
            // lblAbil2
            // 
            this.lblAbil2.AutoSize = true;
            this.lblAbil2.Location = new System.Drawing.Point(124, 149);
            this.lblAbil2.Name = "lblAbil2";
            this.lblAbil2.Size = new System.Drawing.Size(88, 13);
            this.lblAbil2.TabIndex = 14;
            this.lblAbil2.Text = "243,232,421,262";
            // 
            // lblAbil3
            // 
            this.lblAbil3.AutoSize = true;
            this.lblAbil3.Location = new System.Drawing.Point(124, 179);
            this.lblAbil3.Name = "lblAbil3";
            this.lblAbil3.Size = new System.Drawing.Size(88, 13);
            this.lblAbil3.TabIndex = 15;
            this.lblAbil3.Text = "244,305,422,337";
            // 
            // lblAbil4
            // 
            this.lblAbil4.AutoSize = true;
            this.lblAbil4.Location = new System.Drawing.Point(124, 209);
            this.lblAbil4.Name = "lblAbil4";
            this.lblAbil4.Size = new System.Drawing.Size(88, 13);
            this.lblAbil4.TabIndex = 16;
            this.lblAbil4.Text = "244,383,423,411";
            // 
            // lblLevel
            // 
            this.lblLevel.AutoSize = true;
            this.lblLevel.Location = new System.Drawing.Point(124, 239);
            this.lblLevel.Name = "lblLevel";
            this.lblLevel.Size = new System.Drawing.Size(88, 13);
            this.lblLevel.TabIndex = 17;
            this.lblLevel.Text = "343,441,446,475";
            // 
            // lblStars
            // 
            this.lblStars.AutoSize = true;
            this.lblStars.Location = new System.Drawing.Point(124, 268);
            this.lblStars.Name = "lblStars";
            this.lblStars.Size = new System.Drawing.Size(100, 13);
            this.lblStars.TabIndex = 18;
            this.lblStars.Text = "1096,498,1329,538";
            // 
            // lblGear
            // 
            this.lblGear.AutoSize = true;
            this.lblGear.Location = new System.Drawing.Point(124, 298);
            this.lblGear.Name = "lblGear";
            this.lblGear.Size = new System.Drawing.Size(88, 13);
            this.lblGear.TabIndex = 19;
            this.lblGear.Text = "676,500,827,538";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(124, 328);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(94, 13);
            this.lblName.TabIndex = 20;
            this.lblName.Text = "531,536,1007,585";
            // 
            // GetTemplateForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(516, 383);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblGear);
            this.Controls.Add(this.lblStars);
            this.Controls.Add(this.lblLevel);
            this.Controls.Add(this.lblAbil4);
            this.Controls.Add(this.lblAbil3);
            this.Controls.Add(this.lblAbil2);
            this.Controls.Add(this.lblAbil1);
            this.Controls.Add(this.btnName);
            this.Controls.Add(this.btnGear);
            this.Controls.Add(this.btnStars);
            this.Controls.Add(this.btnLevel);
            this.Controls.Add(this.btnAbil4);
            this.Controls.Add(this.btnAbil3);
            this.Controls.Add(this.btnAbil2);
            this.Controls.Add(this.btnAbil1);
            this.Controls.Add(this.btnTags);
            this.Controls.Add(this.lblTags);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.btnPower);
            this.Controls.Add(this.lblPower);
            this.Name = "GetTemplateForm";
            this.Text = "GetTemplateForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPower;
        private System.Windows.Forms.Button btnPower;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Label lblTags;
        private System.Windows.Forms.Button btnTags;
        private System.Windows.Forms.Button btnAbil1;
        private System.Windows.Forms.Button btnAbil2;
        private System.Windows.Forms.Button btnAbil3;
        private System.Windows.Forms.Button btnAbil4;
        private System.Windows.Forms.Button btnLevel;
        private System.Windows.Forms.Button btnStars;
        private System.Windows.Forms.Button btnGear;
        private System.Windows.Forms.Button btnName;
        private System.Windows.Forms.Label lblAbil1;
        private System.Windows.Forms.Label lblAbil2;
        private System.Windows.Forms.Label lblAbil3;
        private System.Windows.Forms.Label lblAbil4;
        private System.Windows.Forms.Label lblLevel;
        private System.Windows.Forms.Label lblStars;
        private System.Windows.Forms.Label lblGear;
        private System.Windows.Forms.Label lblName;
    }
}