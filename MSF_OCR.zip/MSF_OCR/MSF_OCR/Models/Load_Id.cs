﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;


namespace MSF_OCR.Models
{
    
    class Load_Id
    {
        public static List<ID> LoadID_File()
        { 
            List<ID> values = File.ReadAllLines("../../Assets/IDs.csv")
                                           .Skip(1)
                                           .Select(v => ID.FromCsv(v))
                                           .ToList();
            return values;
        }
    }
    public class ID
    {
        public string id;
        public string name;


        public static ID FromCsv(string csvLine)
        {
            string[] values = csvLine.Split(',');
            ID id = new ID();
            id.id = Convert.ToString(values[0]);
            id.name = Convert.ToString(values[1]);
            return id;
        }
    }
}
