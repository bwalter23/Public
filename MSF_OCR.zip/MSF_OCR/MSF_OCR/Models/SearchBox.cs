﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MSF_OCR.Models
{
    public class SearchBox
    {
        public double x1 { get; set; } = 0;
        public double y1 { get; set; } = 0;
        public double x2 { get; set; } = 0;
        public double y2 { get; set; } = 0;

        //public SearchBox()
        //{
        //    x1 = 0;
        //    y1 = 0;
        //    x2 = 0;
        //    y2 = 0;
        //}
    }
}