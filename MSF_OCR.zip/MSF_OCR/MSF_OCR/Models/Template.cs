﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MSF_OCR.Models
{
    public class FieldCoordinates
    {
        public string attribute { get; set; }
        public SearchBox vertices { get; set; }
        public string value { get; set; }

        public FieldCoordinates()
        {
            vertices = new SearchBox();
        }
    }

}

    
