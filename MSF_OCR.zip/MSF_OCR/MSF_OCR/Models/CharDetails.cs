﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MSF_OCR.Models
{
    public class CharDetails
    {
        //public string power { get; set; }
        //public string tags { get; set; }
        //public string ability1Level { get; set; }
        //public string ability2Level { get; set; }
        //public string ability3Level { get; set; }
        //public string ability4Level { get; set; }
        //public string level { get; set; }
        //public string stars { get; set; }
        //public string gear { get; set; }
        //public string name { get; set; }

        public string fieldName { get; set; }
        public string fieldValue { get; set; }


    }   

}
