﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MSF_OCR.Models
{
    public class Roster
    {
        public string CharacterName { get; set; }
        public List<CharDetails> Details { get; set; }

    }
}
